# README
Thank you for buying our product.
This extension adheres to [Magenest](http://magenest.com/).

### User guide
- If you have trouble installing this extension, please visit: http://www.confluence.izysync.com/display/DOC/Popup+Integration+for+Magento+2
- For detailed user guide of this extension, please visit: http://www.confluence.izysync.com/display/DOC/Popup+Integration+for+Magento+2
- Support portal: http://servicedesk.izysync.com/servicedesk/customer/portal/48
- All the updates of this module are included in CHANGELOG.md file.
