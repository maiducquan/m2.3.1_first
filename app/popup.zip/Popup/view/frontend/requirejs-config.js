/**
 * Created by magenest on 15/01/2019.
 */
var config = {
    paths: {
        bioEp: 'Magenest_Popup/js/lib/bioep'
    }
};