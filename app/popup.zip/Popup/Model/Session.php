<?php
namespace Magenest\Popup\Model;

class Session extends \Magento\Framework\Session\SessionManager {

}