<?php
/**
 * Created by PhpStorm.
 * User: mdq
 * Date: 03/05/2019
 * Time: 15:10
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Packt_HelloWorld',
    __DIR__
);
?>
