<?php
/**
 * Created by PhpStorm.
 * User: mdq
 * Date: 03/05/2019
 * Time: 16:59
 */
?>
<p style="color:red">Test</p>
<p style="color:red">Test</p>
<p style="color:red">Test</p>
